# notes

A second stored member, to prove two files come out of one archive.
