Hello from WindClone. This entry is stored, not compressed.
