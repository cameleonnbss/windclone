"""A nested member. A real wheel puts its modules under a package
directory, and since v0.1.36 /bin/unzip honours that name."""
__version__ = "1.0"
